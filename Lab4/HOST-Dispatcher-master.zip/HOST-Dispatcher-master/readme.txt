  Hypothetical Operating System Testbed (HOST) by Henry Williams
	-Memory allocation uses first-fit algorithm
	
	-Written using Notepad++ using tab size of 4.
	
	-To compile, simply place all of files (.c and .h files, and makefile) in the same
	 directory and execute the "make" command. This will create an executable named "hostd".
	
	-To execute, use the command "./hostd <dispatch file>". If the name of the dispatch file
	 is ommitted, then the contents of this file will be displayed on the console.
