RoundRobinDispatcher
====================

Introduction
------------
A round robin dispatcher written in C for the unit of study
[COMP3520 (Operating System Internals)][comp3520] at the
[University of Sydney][usyd].

License
-------
Released under the [MIT License][mit]. See [LICENSE.md](LICENSE.md) for more
details.


[comp3520]: <http://sydney.edu.au/courses/uos/COMP3520/operating-systems-internals>
[mit]: <http://opensource.org/licenses/MIT>
[usyd]: <http://sydney.edu.au>
