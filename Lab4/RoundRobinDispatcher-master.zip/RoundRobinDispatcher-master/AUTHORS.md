Authors
=======
Contributors in the order of first contribution:

* Joshua Spence &lt;<josh@joshuaspence.com>&gt;
